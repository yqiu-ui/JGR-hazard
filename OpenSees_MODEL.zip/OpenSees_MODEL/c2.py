#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 23 18:44:18 2019

@author: yingqing
"""

#import openseespy.opensees as ops
print("=========================================================")
print("1D pore water pressure")


from openseespy.opensees import *
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
import sympy as sym
from math import *
import os.path
# ------------------------------
# Start of model generation
# -----------------------------

# set modelbuilder
set1 = [10.0,10.0,10.0,20.0,20.0,20.0,30.0,30.0,30.0]
set2 = [1.0*10**(-4)/9.81,1.0*10**(-5)/9.81,1.0*10**(-6)/9.81,1.0*10**(-4)/9.81,1.0*10**(-5)/9.81,1.0*10**(-6)/9.81
        ,1.0*10**(-4)/9.81,1.0*10**(-5)/9.81,1.0*10**(-6)/9.81]

for xxx in range((9)):

    wipe()
    model('basic', '-ndm', 2, '-ndf', 3)
    filepath = "../results"
    
    # variables
    soilthick = set1[xxx]
    numlayers = int(set1[xxx])
    layerThick = np.zeros((numlayers,1))
    for i in range(numlayers):
        layerThick[i] = soilthick/numlayers
    rho = 2.16
    Vs1 = 210.0
    Height = np.zeros((numlayers,1))
    Vs = np.zeros((numlayers,1))
    for i in range(numlayers):
        Height[i] = soilthick-(i+1)*layerThick[i]+layerThick[i]/2
        Vs[i] = sqrt(sqrt((rho-1)*9.81*Height[i]/101))*Vs1
        print("Vs[",i+1,"]=",Vs[i])
    G = np.zeros((numlayers,1))
    for k in range(numlayers):
        G[k] = rho*Vs[k]*Vs[k]
        print("G[",k+1,"]=",G[k])
    nu = 0.3
    E = np.zeros((numlayers,1))
    for k in range(numlayers):
        E[k] = 2*G[k]*(1+nu)
        print("E[",k+1,"]=",E[k])
    bulk = np.zeros((numlayers,1))
    for k in range(numlayers):
        bulk[k] = E[k]/(3*(1-2*nu))
        print("bulk[",k+1,"]=",bulk[k])
    
    
    
    damp = 0.02
    omega1 = 2*np.pi*0.2
    omega2 = 2*np.pi*20
    a0 = 2*damp*omega1*omega2/(omega1+omega2)
    a1 = 2*damp/(omega1+omega2)
    
    #print("damping coefficients:",a0)
    
    #Newmark parameters
    gamma = 0.5
    beta = 0.25
    
    # create nodes
    fMax = 15.0
    vsMin = Vs[-1]
    wave = vsMin/fMax
    nEle = 10
    hTrial = wave/nEle
    
    numTotalEle = 0
    
    nElemY = np.zeros((numlayers,1))
    sElemY = np.zeros((numlayers,1))
    nNodeY = np.zeros((numlayers,1))
    for k in range(numlayers):
        
        nTrial = layerThick[k]/hTrial
        if nTrial > floor(layerThick[k]/hTrial):
            nElemY[k] = int(floor(layerThick[k]/hTrial)+1)
        else:
            nElemY[k] = int(nTrial)
            
        numTotalEle = numTotalEle + nElemY[k]
        sElemY[k] = layerThick[k]/nElemY[k]
        print("vertical size of elements = ",sElemY[k])
            
    sElemX = 1.0
    nElemX = 1
    nNodeX = nElemX+1
    
    nNodeYT = 0
    for k in range(numlayers-1):
        nNodeY[k] = nElemY[k]
        nNodeYT = nNodeYT+nNodeY[k]
        
    nNodeY[numlayers-1] = nElemY[numlayers-1]+1
    nNodeYT = nNodeYT+nNodeY[numlayers-1]
    nNodeT = int(nNodeX*(nNodeYT))
    nElemT = nElemX*numTotalEle
    
    
    count = 0
    yCoord = 0.0
    
    for k in range(numlayers):
        for i in range(int(nNodeY[k])):
            for j in range(nNodeX):
                nodeNumber = int(count+i*nNodeX+j+1)
                xCoord = (j)*sElemX
                node(nodeNumber, xCoord, yCoord)
                print("node",nodeNumber,xCoord,yCoord)
            yCoord = yCoord+sElemY[k][0]
        count = count+nNodeY[k]*nNodeX
       
    
    # set boundary condition
    # top nodes
    topnodes = [nNodeT-1,nNodeT]
    for i in topnodes:
        fix(int(i),0,0,1)
    # bottom nodes
    bottomnodes =[1,2]
    for i in bottomnodes:
        fix(i,0,1,0)
    # equal DOF
    for i in range(int(nNodeYT)-1):
        equalDOF((i+2)*2,(i+2)*2-1,1,2)
        
    for i in range(nNodeX-1):
        equalDOF(i+1,i+2,1)
    
    # define materials
    for k in range(numlayers):
        
        nDMaterial('PressureDependMultiYield02',k+1,2.0, rho,G[k][0],bulk[k][0], 36.0, 0.1, 101.0, 0.5,\
               26.0, 0.013, 0.23, 0.06, 0.27, 20.0,5.0, 3.0, 1.0, 0.0, 0.77,0.9,\
               0.02, 0.7, 101.0, 0.1)
    
    # define elements
    thick = 2.0
    einit = 0.46
    n = einit/(1+einit)
    fBulk = 2.2*10**6/n
    H2Odensity = 1.0
    hPerm = set2[xxx]
    vPerm = set2[xxx]
    nodecount = 0
    elemcount = 0
    
    for k in range(numlayers):
        for i in range(int(nElemY[k])):
            for j in range(nElemX):
                
                nI = int(nodecount+j+1+(i)*nNodeX)
                nJ = int(nI+1)
                nK = int(nI+nNodeX+1)
                nL = int(nI+nNodeX)
                elemcount = elemcount+1
                element('quadUP', elemcount, nI,nJ,nK,nL, thick, k+1, fBulk, H2Odensity \
                        , hPerm, vPerm, 0.0, -9.81)
                print('element',elemcount,nI,nJ,nK,nL)
        nodecount = int(nodecount+nNodeY[k]*nNodeX)
       
    #updateElementDomain()    
    for k in range(numlayers):
        updateMaterialStage('-material',k+1,'-stage',0)   
    model('basic', '-ndm', 2, '-ndf', 2)    
    vis1 = int(nNodeT)+1
    vis2 = int(nNodeT)+2
    
    node(vis1,0.0,0.0)
    node(vis2,0.0,0.0)
    
    fix(vis1,1,1)    
    fix(vis2,0,1)    
    
    equalDOF(1,vis2,1)
    
    rockVS = 760
    rockDen = 2.4
    mC = nElemX*sElemX*rockDen*rockVS
    uniaxialMaterial('Viscous', 4000,mC,1.0)
    element('zeroLength', 50000, vis1,vis2, '-mat', 4000, '-dir', 1)
    cfactor = nElemX*sElemX*rockDen*rockVS
    
    recorder('Node','-file',filepath+"pore1_%d.out"% xxx, '-time','-node',\
             '-nodeRange',1, int(nNodeT), '-dof', 3, 'vel')
    
    # gravity loading'pore2mesh_%d.out'% ii
    # create SOE
    wipeAnalysis()
    system("UmfPack")
    
    # create DOF number
    numberer("RCM")
    
    # create constraint handler
    constraints("Transformation")
    
    # create integrator
    integrator("Newmark", 0.5,0.25)
    
    # create algorithm
    algorithm("Newton")
    
    # create test
    test('RelativeNormDispIncr',1e-3, 30,1)
    
    # create analysis object
    analysis("Transient")
    
    analyze(10,500.0)
    print('finished with elastic gravity analysis...')
    for k in range(numlayers):
        updateMaterialStage('-material',k+1,'-stage',1)  
    
    analyze(150,500.0)
    print('Finished with post gravity analysis...')
    
    loadConst('-time',0.0)
    wipeAnalysis()
    remove('recorders')
    
    recorder('Node','-file',filepath+"pore2_%d.out"% xxx, '-time','-node',\
             '-nodeRange',1, nNodeT, '-dof', 3, 'vel')
    
    model('basic', '-ndm', 2, '-ndf', 3)
    
    dt = 0.01
    motionsteps = 29999
    
    
    timeSeries('Path',1, '-filePath', 'earthquakevelo.txt', '-dt', dt,'-factor',cfactor)
    #timeSeries('Path', 2, '-filePath', record+'.dat', '-dt', dt, '-factor', g)
    
    pattern('Plain', 1, 1)
    
    load(1, 1.0,0.0,0.0)
    system("ProfileSPD")
    
    # create DOF number
    numberer("RCM")
    
    # create constraint handler
    constraints("Transformation")
    
    # create integrator
    integrator("Newmark", 0.5,0.25)
    
    # create algorithm
    algorithm("Newton")
    
    # create test
    test('RelativeNormDispIncr',1e-3, 30,1)
    
    rayleigh(a0, a1, 0.0, 0.0)
    
    # create analysis object
    analysis("Transient")
    analyze(motionsteps,dt)
    
    analyze(12840,0.1)
    
    print('loading 1 created...')
    
    loadConst('-time',0.0)
    wipeAnalysis()
    remove('recorders')
    
    for k in range(numlayers):
        updateMaterialStage('-material',k+1,'-stage',0)   
        
        
    model('basic', '-ndm', 2, '-ndf', 3)
    remove('sp',nNodeT-1,3)
    remove('sp',nNodeT,3)
    
    dt2 = 1.0
    recorder('Node','-file',filepath+"pore3_%d.out"% xxx, '-time','-dT', dt2, '-node',\
             '-nodeRange',1, nNodeT, '-dof', 3, 'vel')
    
    # create TimeSeries
    #timeSeries("Trig", 1,0.0,15.0,60.0,'-factor',9.81)
    timeSeries('Path', 2, '-dt', dt2, '-filePath', 'schismwaveshape2.txt', '-factor', 9.81)
    Nsteps = 4588
    # create a plain load pattern
    pattern("MultipleSupport", 20)
    groundMotion(20,'Plain','-vel',2,'-fact',1.0)
    imposedMotion(nNodeT-1,3,20)
    imposedMotion(nNodeT,3,20)
    
    # Create the nodal load
    pattern('Plain',25,2)
    load(nNodeT-1, 0.0,-1.0,0.0)
    load(nNodeT,0.0,-1.0,0.0)
    
    
    # ------------------------------
    # Start of analysis generation
    # ------------------------------
    system("ProfileSPD")
    
    # create DOF number
    numberer("RCM")
    
    # create constraint handler
    constraints("Transformation")
    
    # create integrator
    integrator("Newmark", 0.5,0.25)
    
    # create algorithm
    algorithm("Newton")
    
    # create test
    test('RelativeNormDispIncr',1e-3, 30,1)
    
    # create analysis object
    analysis("Transient")
    
    # ------------------------------
    # Finally perform the analysis
    # ------------------------------
    analyze(Nsteps,dt2)
    #printA('-file','A.dat')
    #printB('-file','B.dat')
    print("finish")
